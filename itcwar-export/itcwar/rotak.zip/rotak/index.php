<?php
session_start();


include_once 'modules/functions/mod-functions.php';
$current_page = "index";
$current_page_title = "Acasă";

?>


<!DOCTYPE html>
<html lang="en">
<head>

<?php include "modules/html/mod-head.php"; ?>

</head>
<body>
<?php include "modules/html/mod-navbar.php"; ?>

<div class = "container">

</div>

<?php include "modules/html/mod-scripts.php"; ?>
</body>
</html>