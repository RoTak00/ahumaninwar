<?php
    $servername = "nl1-ss21.a2hosting.com";
    $username = "formulad_admin";
    $password = "c90,aPgpB[Gm";
    $database = "formulad_rotak";
    
    


// Create connection
    $conn = new mysqli($servername, $username, $password, $database);

// Check connection
    if ($conn->connect_error) {
        AddAlert("Eroare la conectare la baza de date.", "danger");
    die("Connection failed: " . $conn->connect_error);
    }

?>