<?php
    date_default_timezone_set("Europe/Bucharest");

    include_once "./modules/db-config.php";
    include_once "./modules/mod-vars.php";
    include_once "./modules/functions/db-select.php";
    include_once "./modules/html/db-output.php";
    include_once "./modules/functions/general.php";
    include_once "./modules/functions/db-insert.php";

   
?>